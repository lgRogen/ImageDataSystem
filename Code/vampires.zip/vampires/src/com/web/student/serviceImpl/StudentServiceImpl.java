package com.web.student.serviceImpl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.web.student.mapping.StudentMapping;
import com.web.student.model.Student;
import com.web.student.service.StudentService;


@Service("StudentServiceImpl")
public class StudentServiceImpl implements StudentService{
	@Resource(name="StudentMappingImpl")
	private StudentMapping StudentMappingImpl;

	@Override
	public List<Student> queryAll() {
		// TODO Auto-generated method stub
		return StudentMappingImpl.queryAll();
	}

	@Override
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		StudentMappingImpl.addStudent(student);
	}

	@Override
	public Student queryOne(Student student) {
		// TODO Auto-generated method stub
		
		return StudentMappingImpl. queryOne(student);
	}



	

	

}
