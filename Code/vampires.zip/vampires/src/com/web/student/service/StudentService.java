package com.web.student.service;

import java.util.List;

import com.web.student.model.Student;



public interface StudentService {

	List<Student> queryAll();

	void addStudent(Student student);

	Student queryOne(Student student);

}
