package com.web.student.mapping;

import java.util.List;

import com.web.student.model.Student;



public interface StudentMapping {

	List<Student> queryAll();

	void addStudent(Student student);

	Student queryOne(Student student);

}
