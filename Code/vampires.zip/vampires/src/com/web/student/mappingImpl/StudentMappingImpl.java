package com.web.student.mappingImpl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.catalina.core.ApplicationContext;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;

import com.web.student.mapping.StudentMapping;
import com.web.student.model.Student;



@Repository("StudentMappingImpl")
public class StudentMappingImpl implements StudentMapping{
	@Resource(name="sqlSessionFactory")
	private SqlSessionFactory sqlSessionFactory;
	public SqlSessionFactory getSqlSessionFactory() {
		return sqlSessionFactory;
	}
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		this.sqlSessionFactory = sqlSessionFactory;
	}
	
	@Override
	public List<Student> queryAll() {
		// TODO Auto-generated method stub
		SqlSession session=sqlSessionFactory.openSession();
		return session.selectList("sss");
	}
	@Override
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		SqlSession session=sqlSessionFactory.openSession();
        session.insert("insert", student);
	}
	@Override
	public Student queryOne(Student student) {
		// TODO Auto-generated method stub
		SqlSession session=sqlSessionFactory.openSession();
		
		return  session.selectOne("queryone", student);
	}
}