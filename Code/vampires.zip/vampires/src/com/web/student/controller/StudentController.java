package com.web.student.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.wildhorse.server.core.controller.BaseController;

import com.web.common.json.JsonUtil;
import com.web.student.model.Student;
import com.web.student.service.StudentService;

import net.sf.json.JSONObject;








@Controller
@RequestMapping("/login")
public class StudentController  {
	
	@Resource(name="StudentServiceImpl")
	private StudentService StudentServiceImpl;
	/*
	 * 查询
	 */
	//@RequestMapping(params="method=checkLogin")
	@RequestMapping(value = "/checkLogin", method = { RequestMethod.POST, RequestMethod.GET })
	@ResponseBody
	public String checkLogin(HttpServletRequest request, HttpServletResponse response){
		//JSONObject jsonObject = new JSONObject();
		List<Student> list=StudentServiceImpl.queryAll();
		//jsonObject.accumulate("list", list);
		
		System.out.println(JsonUtil.toJson(list));
		//request.setAttribute("list", list);
		 //System.out.println(jsonObject.toString());
		//responseSendMsg(response, jsonObject.toString());
		return JsonUtil.toJson(list);
	}
	

	/*
	 * 添加
	 */
	@RequestMapping(value = "/addStudent", method = { RequestMethod.POST, RequestMethod.GET })
     public String addStudent(HttpServletRequest request, HttpServletResponse response,Student student){
		StudentServiceImpl.addStudent(student);
		
		return "redirect:/login/checkLogin";
	}
	
	
	/*
	 * 
	 */
	
	@RequestMapping(value = "/updatestudent", method = { RequestMethod.POST, RequestMethod.GET })
   @ResponseBody
	public String updatestudent(HttpServletRequest request, HttpServletResponse response,Student student){
		
		
		return JsonUtil.toJson(StudentServiceImpl.queryOne(student));
	}
	
}
