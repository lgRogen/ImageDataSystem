		/**
    		url:页面地址 必填 <br/>
    		org:要向后台传递的参数{ } 可选<br/>
    		func:加载完毕后执行的函数 可选<br/>
    		option: 模态框参数{  backdrop:boolean或 'static' , width : "30%" 百分比     }   可选<br/>
    		id:自己指定模态框id   可选<br/>
    		调用实例 openModule("/jsp/dome/module.html");
    	*/
		function openModule(url,org,func,option,id){
    		var $load;
	    		if(id){
	    			$load = $("#"+id).length > 0 ? $("#"+id):$("<div id='" + id + "'></div>");
	    		}else{
	    			$load = $("#moudle_one").length > 0 ? $("#moudle_one"):$("<div id='moudle_one'></div>");
	    		}
	    		var backdrop = ((typeof option) =='undefined' || (typeof option.backdrop)=='undefined')?'static':option.backdrop;
	    		
    			$load.appendTo($("body"))
    				 .load(url,org, function(){
    					 				option && option.width ? $load.find(".modal-dialog").css({width:option.width}):null;
    					 				$load.find("> .modal").modal({
    					 												show:true,
    					 												backdrop:backdrop
    					 											})
											 .on("hidden.bs.modal", function() {
				    													$(this).removeData("bs.modal");
																	});
    					 				(typeof func)=="function"?func():"";
						});
		}
		
		/**
		 * 模态框关闭
		 * @param id 打开时候用了id 关闭时候传递id
		 */
		function closeModule(id,func){
			if(id){
				$("#"+id).find("> .modal").on("hidden.bs.modal", function() {
					$(this).removeData("bs.modal");
					if(func){
						func();
					}
				});

				 $("#"+id).find("> .modal").modal("hide");
			}else{
				$("#"+id).find("> .modal").on("hidden.bs.modal", function() {
					$(this).removeData("bs.modal");
					if(func){
						func();
					}
				});
				$("#moudle_one").find("> .modal").modal("hide");
			}

		}
		
		
		//交易状态
		function showMsg(obj) {
			var msg = "";
			switch (obj) {
			case '00':
				msg = "操作成功！";
				break;
			case '01':
				msg = "操作失败，请刷新后重试！";
				break;
			case '02':
				msg = "无记录！";
				break;
			case '03':
				msg = "未注册！";
				break;
			case '04':
				msg = "未授权！";
				break;
			case '05':
				msg = "未登录！";
				break;
			case '06':
				msg = "未查询到相关数据！";
				break;
			case '07':
				msg = "无法上传档案附件,因档案状态不是暂存或审核未通过状态！";
				break;
			case '08':
				msg = "无权限删除档案附件！";
				break;
			case '09':
				msg = "无法删除档案附件,因档案状态不是暂存或审核未通过状态！";
				break;
			default:
				msg = obj;
				break;
			}
			if(msg != null && msg != '00' && msg != '' ){
				openAlert(msg,"提示:",1000);
			}
		}
		
		
		/**
		 * 警告框
		 * @param id 打开时候用了id 关闭时候传递id
		 */
		function openAlert(text,title,delay){
			delay = delay?delay:1000;
			var $alert = $("#calert").length > 0 ? $("#calert") : $("<div id='calert' class='alert alert-success' ></div>");
			$alert.html("");
			
			$alert.append("<a href='#' class='close' data-dismiss='alert'>&times;</a>").append("<strong> "+(title?title:'')+" </strong> " + (text?text:''));
			$("body").prepend($alert);
			$alert.css({
				width:300,
				zIndex:2042,
				position:'absolute',
				left: ($(window).width() - 300)/2,
				top: ($(window).height()/3 - $alert.outerHeight())/2 + $(document).scrollTop()
				}); 
			$alert.alert();
			if(delay && delay > 0 ){
				window.setTimeout(function(){
					$alert.alert('close');
				}, delay);
			}
		}
		

	/**
	 * jquery 依赖 bootstrap 插件扩展
	 * pagination: page 为一个json数据 func 为回调函数 同时会回传两个参数 curPage,pageCount
	 */
		$.fn.extend({
			//分页扩展
			pagination:function(page,func){
				var func = func?func:toPage;
				this.empty();
				var pageCount = (page.pageCount > 0)?page.pageCount:20;
				this.addClass("pagination pagination-sm  navbar-right")
				
				this.append($("<li><a href='javascript:void(0)' title='首页'><<</a></li>").click(function(){
					func(1,pageCount);
				}));
				this.append($("<li><a href='javascript:void(0)' title='上一页'><</a></li>").click(function(){
					func(page.curPage<=1?1:(page.curPage-1),pageCount);
				}));
				if(page.maxPage <= 6){
					for(var i = 1; i <= page.maxPage ; i++){
						this.append($("<li " + ((i == page.curPage)?"class='active'":'') + " ><a href='javascript:void(0)'>" + i + "</a></li>").click(i,function(e){
							func(e.data,pageCount);
						}));
					}
				}
				
				if(page.maxPage > 6){
					for(var i = 1; i <= page.maxPage ; i++){
						if(i <= 2){
							this.append($("<li " + ((i == page.curPage)?"class='active'":'') + " ><a href='javascript:void(0)'>" + i + "</a></li>").click(i,function(e){
								func(e.data,pageCount);
							}));
						}
						if(i > 2 && i <= page.maxPage - 2){
							this.append($("<li><a href='javascript:void(0)'>...</a></li>").click(function(e){
								func(page.curPage - 1,pageCount);
							}));
							if(page.curPage > 2 && page.curPage <= page.maxPage - 2){
								this.append($("<li class='active'><a href='javascript:void(0)'>" + page.curPage + "</a></li>").click(function(){
									func(page.curPage,pageCount);
								}));
							}
							this.append($("<li><a href='javascript:void(0)'>...</a></li>").click(i,function(e){
								func(page.curPage + 1,pageCount);
							}));
							i = page.maxPage - 2;
						}
						
						if(i > 3 && i > page.maxPage - 2){
							this.append($("<li " + ((i == page.curPage)?"class='active'":'') + "><a href='javascript:void(0)'>" + i + "</a></li>").click(i,function(e){
								func(e.data,pageCount);
							}));
						}
					}
				}
				this.append($("<li><a href='javascript:void(0)' title='下一页'>></a></li>").click(function(){
					func((page.curPage == page.maxPage)?page.curPage:(page.curPage+1),pageCount);
				}));
				this.append($("<li><a href='javascript:void(0)' title='尾页'>>></a></li>").click(function(){
					func(page.maxPage,pageCount);
				}));
				
				//{"filterRecord":0,"pageCount":15,"curPage":1,"totalRecord":27,"maxPage":2}
				
				var div = $("<div class='input-group input-group-sm'></div>");
				
				$("<span class='input-group-addon' style='background:#fff;color:#337ab7;border-left:none'>每页</span>")
				.appendTo(div)
				
				$("<select class='form-control' style='width: 70px'><option>1</option><option>2</option><option>10</option><option>15</option><option>20</option><option>50</option><option>100</option></select>")
				.appendTo(div)
				.val(page.pageCount)
				.change(function(){
					pageCount = $(this).val();
					func(1,pageCount);
				})
				
				$("<span class='input-group-addon' style='background:#fff;color:#337ab7;'>条</span>")
				.appendTo(div)
				
				this.append($("<li class='form-inline'></li>").append(div));
				
				this.append("<li><span>共" + page.totalRecord + "条</span></li>");
			  	
				var div2 = $("<div class='input-group input-group-sm' style='width:90px;'></div>");
				$("<input type='text' class='form-control'>").appendTo(div2);
				$("<span class='input-group-addon' style='color:#337ab7;cursor: pointer;'>GO</span>")
				.appendTo(div2)
				.click(function(){
					var index = $(this).siblings("input").val();
					if(index && parseInt(index) > 0 && parseInt(index) <=  page.maxPage){
						func(parseInt(index),pageCount);
					}else{
						openAlert("页码超出范围!","警告:",1000);
					}
				});
			  	
			  	this.append($("<li class='form-inline'></li>").append(div2));
			},
			div2Module:function(title){
				var thiz = this;
				var context = thiz.children();
				var id = "mod" + (new Date().getTime());
				title = title?title:"";
				var mcontent = $("<div class='modal-content'><div class='modal-header'><button type='button' class='close' data-dismiss='modal' aria-hidden='true'>&times;</button><h4 class='modal-title'>" + title + "</h4></div></div>");
				mcontent.append(context);
				var mlog = $("<div class='modal-dialog'></div>");
				mlog.append(mcontent);
				var modal = $("<div class='modal fade' id='" + id + "' tabindex='-1' role='dialog'  aria-labelledby='myModalLabel' aria-hidden='true'></div>")
							.append(mlog);
		    	modal.appendTo($("body")).modal({show:true}).on("hidden.bs.modal", function() {
		    		thiz.append(context);
					$(this).removeData("bs.modal");
					modal.remove();
					modal = null;
				});
		    	var close = thiz.close = function(){
		    		modal.modal("hide");
		    	}
		    	thiz.data("dm",close);
		    	return thiz;
			},
			modClose:function(){
				this.data("dm")();
			}
		});
		
		
